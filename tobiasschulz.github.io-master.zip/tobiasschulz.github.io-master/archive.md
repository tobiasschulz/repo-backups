---
layout: default
title: Archive
---

## Blog Posts

{% for post in site.posts %}
  * {{ post.date | date_to_string }} &raquo; [ {{ post.title }} ]({{ post.url }})
{% endfor %}

{% for category in site.categories %}
- {{ category | first }}
  {% for posts in category %}
  {% for post in posts %}
  - [{{ post.title }}]({{ post.url }})
  {% endfor %}
  {% endfor %}
{% endfor %}
