---
layout: startpage
title: About - Tobias Schulz
---

<!--<aside>
	<figure>
		<a href="https://tobias-schulz.github.io/nyc/"><img src="{{site.baseurl}}img/photo3.jpg" style="width: 250px;"></a>
	</figure>
</aside>-->

# Hello !

This is the personal website of Tobias Schulz. I'm a computer science student at the [![FRA-UAS]({{site.baseurl}}img/fra-uas.ico "FRA-UAS") Frankfurt University of Applied Sciences](https://www.frankfurt-university.de/) since April 2015.

<!-- Before that, I studied computer science at the [![KIT]({{site.baseurl}}img/kit.ico "KIT") Karlsruher Institute of Technology](http://www.informatik.kit.edu/) (KIT) in Germany. -->

<br>

**E-Mail**: <tobiasschulz.website@outlook.com>

**Facebook**: <https://www.facebook.com/tobias.schulz1>

<!-- **Google+**: <https://plus.google.com/+TobiasSchulz1/about> -->

**GitHub**: <https://github.com/tobiasschulz>

<!-- **Keybase**: <https://keybase.io/tobiasschulz> -->

<!-- **Xing**: <https://www.xing.com/profile/Tobias_Schulz93/cv> -->

<br><br><br>
