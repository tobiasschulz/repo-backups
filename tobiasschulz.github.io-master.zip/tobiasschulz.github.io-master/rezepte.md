---
layout: default
title: Rezepte
type: rezept
---

# Rezepte

{% for post in site.categories["rezepte"] %}
- [{{ post.title }}]({{ post.url }})
{% endfor %}
