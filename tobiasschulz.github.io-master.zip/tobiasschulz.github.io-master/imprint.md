---
layout: default
title: Imprint - Tobias Schulz
---

# Impressum

## Angaben gem&auml;&szlig; &sect; 5 Telemediengesetz (TMG):

Tobias Schulz<br>
Platanenring 150<br>
61352 Bad Homburg vor der H&ouml;he<br>
Deutschland

## Kontakt:

E-Mail: <tobiasschulz.website@outlook.com>

Verantwortlicher f&uuml;r den Inhalt ist gem&auml;&szlig; &sect; 55 Abs. 2 Rundfunkstaatsvertrag (RStV):

Tobias Schulz<br>
Platanenring 150<br>
61352 Bad Homburg vor der H&ouml;he<br>
Deutschland

